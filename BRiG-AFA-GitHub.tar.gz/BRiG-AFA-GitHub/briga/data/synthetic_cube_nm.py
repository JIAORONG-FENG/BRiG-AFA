"""Synthetic CUBE-NM-style data for non-myopic active feature acquisition."""

from typing import Dict, Tuple

import numpy as np
import torch
from torch.utils.data import TensorDataset


def _make_split(
    n_samples: int,
    n_features: int,
    seed: int,
    noise_std: float,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    rng = np.random.RandomState(seed)
    branch = rng.binomial(1, 0.5, size=n_samples).astype(np.int64)
    x = rng.normal(0.0, 1.0, size=(n_samples, n_features)).astype(np.float32)

    gate_sign = 2.0 * branch.astype(np.float32) - 1.0
    x[:, 0] = gate_sign + rng.normal(0.0, 0.35, size=n_samples).astype(np.float32)

    global_score = 0.55 * x[:, 1] - 0.45 * x[:, 2]
    branch_score = np.zeros(n_samples, dtype=np.float32)
    branch0 = branch == 0
    branch1 = ~branch0
    branch_score[branch0] = (
        1.6 * x[branch0, 3] - 1.1 * x[branch0, 4] + 0.9 * x[branch0, 5]
    )
    branch_score[branch1] = (
        -1.4 * x[branch1, 6] + 1.2 * x[branch1, 7] + 1.0 * x[branch1, 8]
    )
    score = global_score + branch_score
    score += rng.normal(0.0, noise_std, size=n_samples).astype(np.float32)
    y = (score > 0.0).astype(np.int64)

    return torch.from_numpy(x), torch.from_numpy(y), torch.from_numpy(branch)


def make_synthetic_cube_nm_data(
    n_train: int = 6000,
    n_val: int = 2000,
    n_test: int = 2000,
    n_features: int = 12,
    seed: int = 0,
    noise_std: float = 0.25,
) -> Dict[str, object]:
    """Create a small non-myopic AFA benchmark.

    Feature 0 is a gate/context feature. Features 1-2 are globally useful but
    limited. Features 3-5 matter for branch 0, features 6-8 matter for branch
    1, and features 9-11 are distractors. The gate alone is weak for immediate
    classification, but it identifies which downstream feature group is useful.
    """
    if n_features < 12:
        raise ValueError("n_features must be at least 12")

    train_x, train_y, train_branch = _make_split(n_train, n_features, seed, noise_std)
    val_x, val_y, val_branch = _make_split(n_val, n_features, seed + 1, noise_std)
    test_x, test_y, test_branch = _make_split(n_test, n_features, seed + 2, noise_std)

    feature_costs = torch.ones(n_features, dtype=torch.float32)
    metadata = {
        "train_regime": train_branch,
        "val_regime": val_branch,
        "test_regime": test_branch,
        "context_feature": 0,
        "global_informative": [1, 2],
        "regime0_informative": [3, 4, 5],
        "regime1_informative": [6, 7, 8],
        "distractor_features": list(range(9, n_features)),
    }

    return {
        "train": TensorDataset(train_x, train_y),
        "val": TensorDataset(val_x, val_y),
        "test": TensorDataset(test_x, test_y),
        "train_tensors": (train_x, train_y),
        "val_tensors": (val_x, val_y),
        "test_tensors": (test_x, test_y),
        "feature_costs": feature_costs,
        "metadata": metadata,
        "n_features": n_features,
        "n_classes": 2,
    }
