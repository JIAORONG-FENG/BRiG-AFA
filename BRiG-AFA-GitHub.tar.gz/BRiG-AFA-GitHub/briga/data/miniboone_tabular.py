"""MiniBooNE real numeric tabular dataset for BRiG-AFA.

This module is intentionally separate from real_tabular.py to avoid touching the
Breast Cancer smoke benchmark loader. It loads the UCI MiniBooNE text file,
optionally takes a stratified subsample, standardizes features using train
statistics only, and returns the same dictionary structure as the synthetic
generators.
"""

from typing import Dict, Tuple

import numpy as np
import torch
from torch.utils.data import TensorDataset


def _standardize_from_train(
    train_x: np.ndarray,
    val_x: np.ndarray,
    test_x: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    mean = train_x.mean(axis=0, keepdims=True)
    std = train_x.std(axis=0, keepdims=True)
    std = np.where(std < 1e-8, 1.0, std)

    train_z = (train_x - mean) / std
    val_z = (val_x - mean) / std
    test_z = (test_x - mean) / std

    return train_z, val_z, test_z, mean.squeeze(0), std.squeeze(0)


def _load_miniboone_from_uci(cache_dir: str) -> Tuple[np.ndarray, np.ndarray, Dict[str, object]]:
    """Load MiniBooNE particle-identification data from UCI.

    The first line contains:
        n_signal n_background

    Signal rows come first, followed by background rows.
    """
    import os
    import urllib.request

    os.makedirs(cache_dir, exist_ok=True)

    file_path = os.path.join(cache_dir, "MiniBooNE_PID.txt")
    url = "https://archive.ics.uci.edu/ml/machine-learning-databases/00199/MiniBooNE_PID.txt"

    if not os.path.exists(file_path):
        print("downloading MiniBooNE from UCI")
        print("url:", url)
        print("to:", file_path)
        urllib.request.urlretrieve(url, file_path)

    with open(file_path, "r") as handle:
        header = handle.readline().strip().split()

    if len(header) != 2:
        raise ValueError("Unexpected MiniBooNE header: {}".format(header))

    n_signal = int(header[0])
    n_background = int(header[1])
    expected_rows = n_signal + n_background

    x = np.loadtxt(file_path, skiprows=1, dtype=np.float32)

    if x.ndim != 2:
        raise ValueError("Expected 2D MiniBooNE feature matrix, got shape {}".format(x.shape))

    if x.shape[0] != expected_rows:
        raise ValueError(
            "MiniBooNE row mismatch: got {}, expected {}".format(
                x.shape[0], expected_rows
            )
        )

    y = np.concatenate(
        [
            np.ones(n_signal, dtype=np.int64),
            np.zeros(n_background, dtype=np.int64),
        ],
        axis=0,
    )

    metadata = {
        "source": "UCI MiniBooNE_PID.txt",
        "uci_url": url,
        "uci_n_signal": int(n_signal),
        "uci_n_background": int(n_background),
        "target_names": ["background", "signal"],
        "target_encoding": {"background": 0, "signal": 1},
    }

    return x.astype(np.float32), y.astype(np.int64), metadata


def make_miniboone_data(
    seed: int = 7,
    val_size: float = 0.20,
    test_size: float = 0.20,
    max_samples: int = 30000,
    cache_dir: str = None,
) -> Dict[str, object]:
    """Create a MiniBooNE real numeric tabular dataset.

    By default, this uses a stratified 30k subsample. Set max_samples=0 to use
    the full dataset.
    """
    import os
    from sklearn.model_selection import train_test_split

    if val_size <= 0 or test_size <= 0 or val_size + test_size >= 1:
        raise ValueError("val_size and test_size must be positive and sum to less than 1.")

    if cache_dir is None:
        cache_dir = os.environ.get(
            "BRIGA_DATA_CACHE",
            os.path.expanduser("~/.cache/briga_afa"),
        )

    uci_cache_dir = os.path.join(cache_dir, "uci")
    x, y, source_metadata = _load_miniboone_from_uci(uci_cache_dir)

    if x.shape[0] != y.shape[0]:
        raise ValueError("x/y row mismatch: {} vs {}".format(x.shape[0], y.shape[0]))

    if len(np.unique(y)) != 2:
        raise ValueError("MiniBooNE should be binary, got labels {}".format(np.unique(y)))

    original_n_samples = int(x.shape[0])

    if max_samples is not None and int(max_samples) > 0 and int(max_samples) < x.shape[0]:
        _, x, _, y = train_test_split(
            x,
            y,
            test_size=int(max_samples),
            random_state=seed,
            stratify=y,
        )

    used_n_samples = int(x.shape[0])

    x_train_val, x_test, y_train_val, y_test = train_test_split(
        x,
        y,
        test_size=test_size,
        random_state=seed + 10,
        stratify=y,
    )

    relative_val_size = val_size / (1.0 - test_size)
    x_train, x_val, y_train, y_val = train_test_split(
        x_train_val,
        y_train_val,
        test_size=relative_val_size,
        random_state=seed + 11,
        stratify=y_train_val,
    )

    x_train, x_val, x_test, mean, std = _standardize_from_train(x_train, x_val, x_test)

    train_x = torch.from_numpy(x_train.astype(np.float32))
    val_x = torch.from_numpy(x_val.astype(np.float32))
    test_x = torch.from_numpy(x_test.astype(np.float32))

    train_y = torch.from_numpy(y_train.astype(np.int64))
    val_y = torch.from_numpy(y_val.astype(np.int64))
    test_y = torch.from_numpy(y_test.astype(np.int64))

    n_features = int(train_x.size(1))
    n_classes = int(len(np.unique(y)))

    feature_costs = torch.ones(n_features, dtype=torch.float32)

    metadata = {
        "dataset_name": "miniboone",
        "task_type": "binary_classification",
        "feature_type": "real_numeric",
        "original_n_samples": int(original_n_samples),
        "used_n_samples": int(used_n_samples),
        "n_features": int(n_features),
        "standardization": "train_mean_std",
        "train_mean": mean.astype(float).tolist(),
        "train_std": std.astype(float).tolist(),
        "val_size": float(val_size),
        "test_size": float(test_size),
        "max_samples": int(max_samples) if max_samples is not None else None,
        "seed": int(seed),
        "cache_dir": str(cache_dir),
    }
    metadata.update(source_metadata)

    return {
        "train": TensorDataset(train_x, train_y),
        "val": TensorDataset(val_x, val_y),
        "test": TensorDataset(test_x, test_y),
        "train_tensors": (train_x, train_y),
        "val_tensors": (val_x, val_y),
        "test_tensors": (test_x, test_y),
        "feature_costs": feature_costs,
        "metadata": metadata,
        "n_features": n_features,
        "n_classes": n_classes,
    }
