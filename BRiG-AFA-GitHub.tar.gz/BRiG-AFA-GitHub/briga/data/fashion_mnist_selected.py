"""Fashion-MNIST selected-pixel dataset for lightweight AFA probes."""

import os
from typing import Dict, List, Tuple

import torch
from torch.utils.data import TensorDataset


DEFAULT_CACHE_DIR = os.path.expanduser(
    os.environ.get("BRIGA_DATA_CACHE", "~/.cache/briga_afa/torchvision")
)

SELECTED_PIXEL_INDICES = [
    10,
    38,
    121,
    146,
    202,
    246,
    248,
    341,
    343,
    362,
    406,
    434,
    454,
    490,
    546,
    574,
    580,
    602,
    742,
    770,
]

CLASS_NAMES = [
    "T-shirt/top",
    "Trouser",
    "Pullover",
    "Dress",
    "Coat",
    "Sandal",
    "Shirt",
    "Sneaker",
    "Bag",
    "Ankle boot",
]


def _validate_pixel_indices(indices: List[int], original_n_features: int) -> None:
    invalid = [int(idx) for idx in indices if int(idx) < 0 or int(idx) >= original_n_features]
    if invalid:
        raise ValueError(
            "Selected pixel indices out of bounds for flattened image dimension {}: {}".format(
                original_n_features, invalid
            )
        )


def _flatten_select_normalize(images: torch.Tensor, selected_indices: List[int]) -> torch.Tensor:
    flat = images.reshape(images.size(0), -1).float() / 255.0
    return flat[:, torch.tensor(selected_indices, dtype=torch.long)]


def _stratified_train_val_indices(
    labels: torch.Tensor,
    train_size: int,
    val_size: int,
    seed: int,
) -> Tuple[torch.Tensor, torch.Tensor]:
    from sklearn.model_selection import train_test_split

    all_indices = torch.arange(labels.numel(), dtype=torch.long).numpy()
    train_idx, val_idx = train_test_split(
        all_indices,
        train_size=int(train_size),
        test_size=int(val_size),
        random_state=int(seed),
        stratify=labels.numpy(),
    )
    return torch.from_numpy(train_idx).long(), torch.from_numpy(val_idx).long()


def make_fashion_mnist_selected_data(
    seed: int = 7,
    cache_dir: str = DEFAULT_CACHE_DIR,
    download: bool = True,
) -> Dict[str, object]:
    """Create the 20-selected-pixel Fashion-MNIST probe dataset."""
    from torchvision.datasets import FashionMNIST

    train_source = FashionMNIST(root=cache_dir, train=True, download=download)
    test_source = FashionMNIST(root=cache_dir, train=False, download=download)

    original_n_features = 28 * 28
    selected_pixel_indices = [int(idx) for idx in SELECTED_PIXEL_INDICES]
    _validate_pixel_indices(selected_pixel_indices, original_n_features)

    train_val_x = _flatten_select_normalize(train_source.data, selected_pixel_indices)
    train_val_y = train_source.targets.long()
    test_x = _flatten_select_normalize(test_source.data, selected_pixel_indices)
    test_y = test_source.targets.long()

    train_idx, val_idx = _stratified_train_val_indices(
        train_val_y,
        train_size=50000,
        val_size=10000,
        seed=seed,
    )

    train_x = train_val_x[train_idx]
    train_y = train_val_y[train_idx]
    val_x = train_val_x[val_idx]
    val_y = train_val_y[val_idx]

    n_features = int(train_x.size(1))
    n_classes = int(torch.unique(train_val_y).numel())
    feature_costs = torch.ones(n_features, dtype=torch.float32)

    metadata = {
        "dataset_name": "fashion_mnist_selected",
        "task_type": "multiclass_classification",
        "feature_type": "selected_pixels",
        "seed": int(seed),
        "cache_dir": str(cache_dir),
        "original_image_shape": [28, 28],
        "original_n_features": int(original_n_features),
        "selected_pixel_indices": selected_pixel_indices,
        "n_features": int(n_features),
        "n_classes": int(n_classes),
        "class_names": list(CLASS_NAMES),
        "pixel_normalization": "divide_by_255",
        "train_size": int(train_x.size(0)),
        "val_size": int(val_x.size(0)),
        "test_size": int(test_x.size(0)),
        "official_test": True,
    }

    return {
        "train": TensorDataset(train_x, train_y),
        "val": TensorDataset(val_x, val_y),
        "test": TensorDataset(test_x, test_y),
        "train_tensors": (train_x, train_y),
        "val_tensors": (val_x, val_y),
        "test_tensors": (test_x, test_y),
        "feature_costs": feature_costs,
        "metadata": metadata,
        "n_features": n_features,
        "n_classes": n_classes,
    }
